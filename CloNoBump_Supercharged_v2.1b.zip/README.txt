 ______________     _____   __     ________                                         
 __  ____/__  /________  | / /________  __ )___  ________ ___________               
 _  /    __  /_  __ \_   |/ /_  __ \_  __  |  / / /_  __ `__ \__  __ \              
 / /___  _  / / /_/ /  /|  / / /_/ /  /_/ // /_/ /_  / / / / /_  /_/ /              
 \____/  /_/  \____//_/ |_/  \____//_____/ \__,_/ /_/ /_/ /_/_  .___/               
                                                            /_/                    
 ________                                ______                            _________
 __  ___/___  ______________________________  /_______ ______________ ___________  /
 _____ \_  / / /__  __ \  _ \_  ___/  ___/_  __ \  __ `/_  ___/_  __ `/  _ \  __  / 
 ____/ // /_/ /__  /_/ /  __/  /   / /__ _  / / / /_/ /_  /   _  /_/ //  __/ /_/ /  
 /____/ \__,_/ _  .___/\___//_/    \___/ /_/ /_/\__,_/ /_/    _\__, / \___/\__,_/ v2.1
              /_/                                            /____/                
Supercharge your Sonic & All-Stars Racing Transformed!

What can CloNoBump Supercharged do?
 -> Remove collisions between racers
 -> Remove AI racers (offline and custom games)
 -> Allow players to select the same character
 -> Change the number of seconds before getting DNF in a race
 -> Make all players start the race in the same position
 -> Make all vehicles (except your own) invisible for a few seconds after race start
 -> Allow local custom games without needing extra players (boost/battle single races!)
 -> Change the speed/boost/acceleration/handling stats for all characters
 -> Works in offline and online modes (custom games only)
 -> Fully configurable, by editing settings.xml

How to install
 1. Open the zip file and extract the CloNoBump Supercharged folder (does not matter where)
 2. Start Sonic & All-Stars Racing Transformed
 3. Run "CloNoBump Supercharged.exe"
 4. A message should appear saying CloNoBump Supercharged is enabled
 5. Please carefully read the additional information in the message

How to uninstall
 -> Run "CloNoBump Supercharged.exe" again, and choose to disable CloNoBump
 -> Alternatively, close and re-open Sonic & All-Stars Racing Transformed

I hope you enjoy the mod. :)
Tyapp